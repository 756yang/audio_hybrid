//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Wizard97Test.rc
//
#define IDD_WIZ97_INTERIOR_BLANK        110
#define IDD_WIZ97_EXTERIOR_BLANK        111
#define IDD_WIZ97_WELCOME               115
#define IDD_WIZ97_COMPLETION            116
#define IDD_WIZ97_PATHFILTER            117
#define IDD_WIZ97_FILEPREVIEW           118
#define IDD_WIZ97_OUTPUT                119

#define IDB_WIZ97_HEADER                1000
#define IDB_WIZ97_WATERMARK             1001

#define IDC_WIZ97_EXTERIOR_TITLE        1004
#define IDC_WIZ97_EXTERIOR_DESC         1005
#define IDC_WIZ97_WELCOME_NOTAGAIN      1006
#define IDC_WIZ97_SUMMARY               1007
#define IDC_WIZ97_EXTERIOR_CLICKFINISH  1008
#define IDC_WIZ97_BULLET1               1011
#define IDC_WIZ97_BULLET2               1012
#define IDC_WIZ97_BULLET3               1013
#define IDC_WIZ97_BULLET4               1014
#define IDC_WIZ97_BULLET5               1015
#define IDC_WIZ97_BULLET6               1016
#define IDC_WIZ97_BULLET7               1017
#define IDC_WIZ97_BULLET8               1018
#define IDC_WIZ97_BULLET9               1019
#define IDC_WIZ97_BULLET1_DESC          1021
#define IDC_WIZ97_BULLET2_DESC          1022
#define IDC_WIZ97_BULLET3_DESC          1023
#define IDC_WIZ97_BULLET4_DESC          1024
#define IDC_WIZ97_BULLET5_DESC          1025
#define IDC_WIZ97_BULLET6_DESC          1026
#define IDC_WIZ97_BULLET7_DESC          1027
#define IDC_WIZ97_BULLET8_DESC          1028
#define IDC_WIZ97_BULLET9_DESC          1029
#define IDC_LABEL_DESCRIPTION           1101
#define IDC_LABEL_PATH                  1102
#define IDC_EDIT_PATH                   1103
#define IDC_BTN_BROWSEPATH              1104
#define IDC_RADIO_RECURSE               1105
#define IDC_RADIO_NORECURSE             1106
#define IDC_LABEL_FILTER                1107
#define IDC_RADIO_FILTER_ALL            1108
#define IDC_RADIO_FILTER_CUSTOM         1109
#define IDC_EDIT_FILTER                 1110
#define IDC_LIST_FILES                  1120
#define IDC_BTN_ADD                     1121
#define IDC_BTN_REMOVE                  1122
#define IDC_BTN_PREVIEW                 1123
#define IDC_RADIO_COPYTOCLIPBOARD       1200
#define IDC_RADIO_SENDEMAIL             1201
#define IDC_RADIO_SAVETOFILE            1202
#define IDC_EDIT_SAVETOFILE             1203
#define IDC_BTN_FILEBROWSE              1204
#define IDC_LABEL_FILEENCODING          1205
#define IDC_COMBO_FILEENCODING          1206
#define IDC_LABEL_FILENAME              1207

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1208
#define _APS_NEXT_SYMED_VALUE           201
#endif
#endif
