//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MDI.rc
//
#define IDR_MAINFRAME                   2
#define ID_BLACK                        20
#define ID_RED                          21
#define ID_GREEN                        22
#define ID_BLUE                         23
#define ID_WHITE                        24
#define ID_CUSTOM                       25
#define IDD_ABOUTDLG                    104
#define IDR_HELLOTYPE                   129
#define IDR_BOUNCETYPE                  31234
#define ID_FILE_NEWHELLO                32771
#define ID_FILE_NEWBOUNCE               32772
#define ID_SPEED_SLOW                   32778
#define ID_SPEED_FAST                   32779
#define IDS_NOHELLOTEMPLATE             32780
#define IDS_NOBOUNCETEMPLATE            32781
#define ID_MIX                          32783
#define IDS_UNKCOLOR                    32784
#define ID_WINDOW_ARRANGEICONS          40003
#define ID_WINDOW_MINIMIZEALL           40004
#define ID_WINDOW_CASCADE2              57652
#define ID_WINDOW_TILE_HORZ2            57653
#define ID_WINDOW_TILE_VERT2            57654
#define ID_WINDOW_SPLIT2                57655

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
