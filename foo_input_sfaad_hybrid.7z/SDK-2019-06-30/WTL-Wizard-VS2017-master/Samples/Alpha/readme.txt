Alpha WTL Sample
----------------

This sample shows how to use 32-bit (alpha channel) images with toolbars and
command bars. It also displays them only if running on Windows XP with themes
enabled, while it displays standard 4-bit images in other cases.

Cut and Copy commands toggle enable/disable state for the Paste command, just
to show how images look disabled.

Subdirectories Release and Debug contain the manifest file, alpha.exe.manifest
which is required to use 32-bit (alpha) images. If you use Windows XP with
themes, you can rename or delete the manifest file to disable alpha images.

-end-
